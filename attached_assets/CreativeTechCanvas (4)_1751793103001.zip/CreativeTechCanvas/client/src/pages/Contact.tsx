import { ContactSection } from "@/components/sections/ContactSection";
import { Navigation } from "@/components/ui/navigation";

export default function Contact() {
  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <Navigation />
      <main className="pt-20">
        <ContactSection />
      </main>
    </div>
  );
}