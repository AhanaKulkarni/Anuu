import { BlogSection } from "@/components/sections/BlogSection";
import { Navigation } from "@/components/ui/navigation";

export default function Blog() {
  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <Navigation />
      <main className="pt-20">
        <BlogSection />
      </main>
    </div>
  );
}