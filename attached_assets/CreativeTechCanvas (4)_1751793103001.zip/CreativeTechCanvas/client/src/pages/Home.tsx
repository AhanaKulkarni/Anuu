import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Navigation } from "@/components/ui/navigation";
import { HeroSection } from "@/components/sections/HeroSection";
import { AboutSection } from "@/components/sections/AboutSection";

import { ServicesSection } from "@/components/sections/ServicesSection";
import { PortfolioSection } from "@/components/sections/PortfolioSection";


import { ContactSection } from "@/components/sections/ContactSection";
import { Button } from "@/components/ui/button";
import { AnimatedCursor } from "@/components/ui/AnimatedCursor";
import { SOCIAL_LINKS } from "@/lib/constants";

export default function Home() {


  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };



  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      <AnimatedCursor />
      
      {/* Global Particle System */}
      <div className="floating-particles fixed inset-0 z-0">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="particle morphing-shape"
            style={{
              width: Math.random() * 60 + 20 + 'px',
              height: Math.random() * 60 + 20 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animationDelay: Math.random() * 8 + 's',
              animationDuration: (Math.random() * 4 + 6) + 's'
            }}
          />
        ))}
      </div>
      
      <Navigation />
      
      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <PortfolioSection />
        <ContactSection />
      </main>



      {/* Final CTA Section */}
      <section className="bg-gradient-to-r from-accent to-[hsl(43,96%,56%)] py-20">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center text-white">
          <h2 className="text-4xl md:text-5xl font-bold font-space mb-6">
            Ready to Bring Your Vision to Life?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Let's collaborate on creating something meaningful together. Whether it's a website, app, or compelling story, I'm here to help turn your ideas into reality.
          </p>
          <Button 
            onClick={() => handleNavClick("#contact")}
            className="bg-white text-accent hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Let's Start Creating
            <i className="fas fa-arrow-right ml-2"></i>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-white py-16 dark:bg-black">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="font-space font-bold text-3xl mb-4">
                Ahana <span className="gradient-text">Kulkarni</span>
              </div>
              <p className="text-gray-300 mb-6 text-lg">
                Multi-disciplinary creator blending art, technology, and human emotion into powerful digital experiences that connect with audiences and drive meaningful results.
              </p>
              <div className="flex gap-6">
                {SOCIAL_LINKS.map((social) => (
                  <a
                    key={social.label}
                    href={social.url}
                    className="text-gray-300 hover:text-accent transition-colors text-2xl"
                    aria-label={social.label}
                  >
                    <i className={social.icon}></i>
                  </a>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-bold text-xl mb-6 text-accent">Services</h4>
              <ul className="space-y-3 text-gray-300">
                <li><button onClick={() => handleNavClick("#services")} className="hover:text-white transition-colors flex items-center"><i className="fas fa-palette mr-2 text-accent"></i>UI/UX Design</button></li>
                <li><button onClick={() => handleNavClick("#services")} className="hover:text-white transition-colors flex items-center"><i className="fas fa-code mr-2 text-accent"></i>Frontend Development</button></li>
                <li><button onClick={() => handleNavClick("#services")} className="hover:text-white transition-colors flex items-center"><i className="fas fa-film mr-2 text-accent"></i>Scriptwriting</button></li>
                <li><button onClick={() => handleNavClick("#services")} className="hover:text-white transition-colors flex items-center"><i className="fas fa-lightbulb mr-2 text-accent"></i>Creative Direction</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold text-xl mb-6 text-[hsl(43,96%,56%)]">Why Work With Me</h4>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-center"><i className="fas fa-heart mr-2 text-[hsl(43,96%,56%)]"></i>Passionate About Quality</li>
                <li className="flex items-center"><i className="fas fa-clock mr-2 text-[hsl(43,96%,56%)]"></i>Always On Time</li>
                <li className="flex items-center"><i className="fas fa-comments mr-2 text-[hsl(43,96%,56%)]"></i>Clear Communication</li>
                <li className="flex items-center"><i className="fas fa-handshake mr-2 text-[hsl(43,96%,56%)]"></i>Collaborative Approach</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center text-gray-300">
              <p>&copy; 2024 Ahana Kulkarni. All rights reserved. Built with passion in India.</p>
              <div className="mt-4 md:mt-0">
                <span className="text-accent font-semibold">Budget Range: ₹5,000 - ₹5,00,000</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
