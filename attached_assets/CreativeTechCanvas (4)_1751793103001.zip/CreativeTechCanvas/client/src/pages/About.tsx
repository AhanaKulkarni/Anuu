import { AboutSection } from "@/components/sections/AboutSection";
import { Navigation } from "@/components/ui/navigation";

export default function About() {
  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <Navigation />
      <main className="pt-20">
        <AboutSection />
      </main>
    </div>
  );
}