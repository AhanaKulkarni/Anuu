import { Navigation } from "@/components/ui/navigation";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Award, BookOpen, Code, Palette, Eye, Brain } from "lucide-react";

const certifications = [
  {
    title: "Complete A.I. & Machine Learning, Data Science Bootcamp",
    platform: "Udemy",
    icon: <Brain className="w-8 h-8" />,
    status: "completed",
    category: "AI/ML",
    skills: ["Machine Learning", "Data Science", "Python", "AI Algorithms"]
  },
  {
    title: "Effective Communication Skills for Business (Updated 2025)",
    platform: "Udemy", 
    icon: <BookOpen className="w-8 h-8" />,
    status: "completed",
    category: "Business",
    skills: ["Communication", "Business Skills", "Leadership", "Presentation"]
  },
  {
    title: "The Complete Full-Stack Web Development Bootcamp",
    platform: "Udemy",
    icon: <Code className="w-8 h-8" />,
    status: "completed", 
    category: "Development",
    skills: ["HTML/CSS", "JavaScript", "React", "Node.js", "Database"]
  },
  {
    title: "Complete Web Design: From Figma to Webflow to Freelancing",
    platform: "Udemy",
    icon: <Palette className="w-8 h-8" />,
    status: "completed",
    category: "Design",
    skills: ["Figma", "Webflow", "UI/UX Design", "Freelancing", "Web Design"]
  },
  {
    title: "Introduction to WebAR Development",
    platform: "Udemy",
    icon: <Eye className="w-8 h-8" />,
    status: "completed",
    category: "AR/VR",
    skills: ["WebAR", "AR.js", "3D Development", "Augmented Reality"]
  },
  {
    title: "Computer Vision & Deep Learning Python and OpenCV",
    platform: "Udemy",
    icon: <Eye className="w-8 h-8" />,
    status: "learning",
    category: "AI/ML",
    skills: ["Computer Vision", "OpenCV", "Deep Learning", "Python", "Neural Networks"]
  }
];

const getCategoryColor = (category: string) => {
  switch (category) {
    case 'AI/ML': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
    case 'Development': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    case 'Design': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200';
    case 'Business': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    case 'AR/VR': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'completed': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200';
    case 'learning': return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  }
};

export default function Certifications() {
  const completedCerts = certifications.filter(cert => cert.status === 'completed');
  const learningCerts = certifications.filter(cert => cert.status === 'learning');

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <Navigation />
      <main className="pt-20">
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            {/* Header */}
            <div className="text-center mb-16">
              <span className="text-accent font-medium text-lg">Professional Development</span>
              <h1 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6">
                <span className="gradient-text">Certifications</span> & Learning
              </h1>
              <p className="text-neutral text-xl max-w-3xl mx-auto">
                Continuous learning and skill development through industry-recognized courses and certifications.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
              <div className="text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl">
                <Award className="w-8 h-8 text-accent mx-auto mb-2" />
                <div className="text-3xl font-bold text-foreground">{completedCerts.length}</div>
                <div className="text-neutral">Completed</div>
              </div>
              <div className="text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl">
                <BookOpen className="w-8 h-8 text-accent mx-auto mb-2" />
                <div className="text-3xl font-bold text-foreground">{learningCerts.length}</div>
                <div className="text-neutral">In Progress</div>
              </div>
              <div className="text-center p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl">
                <Brain className="w-8 h-8 text-accent mx-auto mb-2" />
                <div className="text-3xl font-bold text-foreground">5</div>
                <div className="text-neutral">Categories</div>
              </div>
            </div>

            {/* Completed Certifications */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
                <Award className="w-6 h-6 text-accent" />
                Completed Certifications
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {completedCerts.map((cert, index) => (
                  <Card key={index} className="group hover:shadow-lg transition-all duration-300 border border-gray-200 dark:border-gray-700">
                    <CardHeader className="pb-4">
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-accent/10 rounded-lg text-accent">
                          {cert.icon}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <h3 className="font-semibold text-lg leading-tight">{cert.title}</h3>
                            <Badge className={getStatusColor(cert.status)}>
                              Completed
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mb-3">
                            <span className="text-sm text-neutral">{cert.platform}</span>
                            <Badge variant="outline" className={getCategoryColor(cert.category)}>
                              {cert.category}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex flex-wrap gap-2">
                        {cert.skills.map((skill, skillIndex) => (
                          <Badge key={skillIndex} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Currently Learning */}
            <div>
              <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
                <BookOpen className="w-6 h-6 text-accent" />
                Currently Learning
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {learningCerts.map((cert, index) => (
                  <Card key={index} className="group hover:shadow-lg transition-all duration-300 border border-gray-200 dark:border-gray-700 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent to-accent/50"></div>
                    <CardHeader className="pb-4">
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-accent/10 rounded-lg text-accent">
                          {cert.icon}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <h3 className="font-semibold text-lg leading-tight">{cert.title}</h3>
                            <Badge className={getStatusColor(cert.status)}>
                              In Progress
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mb-3">
                            <span className="text-sm text-neutral">{cert.platform}</span>
                            <Badge variant="outline" className={getCategoryColor(cert.category)}>
                              {cert.category}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex flex-wrap gap-2">
                        {cert.skills.map((skill, skillIndex) => (
                          <Badge key={skillIndex} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}