import { ServicesSection } from "@/components/sections/ServicesSection";
import { Navigation } from "@/components/ui/navigation";

export default function Services() {
  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <Navigation />
      <main className="pt-20">
        <ServicesSection />
      </main>
    </div>
  );
}