import { PortfolioSection } from "@/components/sections/PortfolioSection";
import { Navigation } from "@/components/ui/navigation";

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-white dark:bg-black">
      <Navigation />
      <main className="pt-20">
        <PortfolioSection />
      </main>
    </div>
  );
}