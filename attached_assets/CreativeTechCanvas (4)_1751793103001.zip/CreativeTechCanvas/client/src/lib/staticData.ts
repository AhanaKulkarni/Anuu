// Static blog posts data to replace backend
export const STATIC_BLOG_POSTS = [
  {
    id: 1,
    title: "The Art of Minimalist UI Design",
    excerpt: "Exploring how less can be more in creating powerful user interfaces that prioritize clarity and functionality.",
    content: "In the world of UI design, minimalism isn't just about removing elements—it's about creating intentional, purposeful experiences...",
    category: "Design Theory",
    tags: ["UI Design", "Minimalism", "User Experience"],
    publishedAt: "2024-12-01",
    readingTime: 5,
    featured: true
  },
  {
    id: 2,
    title: "Building Accessible Design Systems",
    excerpt: "Creating inclusive design systems that work for everyone, from initial planning to implementation.",
    content: "Accessibility in design systems isn't an afterthought—it's a fundamental principle that should guide every decision...",
    category: "Design Systems",
    tags: ["Accessibility", "Design Systems", "Inclusive Design"],
    publishedAt: "2024-11-15",
    readingTime: 8,
    featured: true
  },
  {
    id: 3,
    title: "From Script to Screen: Digital Storytelling",
    excerpt: "How scriptwriting principles enhance digital experiences and create compelling user narratives.",
    content: "Every interface tells a story. As someone who works in both scriptwriting and UI design, I've learned that the best digital experiences...",
    category: "Creative Technology",
    tags: ["Storytelling", "UX Writing", "Narrative Design"],
    publishedAt: "2024-11-01",
    readingTime: 6,
    featured: false
  },
  {
    id: 4,
    title: "The Psychology of Color in Web Design",
    excerpt: "Understanding how color choices impact user behavior and emotional response in digital interfaces.",
    content: "Color is one of the most powerful tools in a designer's arsenal. It can guide attention, evoke emotions, and influence decisions...",
    category: "User Experience",
    tags: ["Color Theory", "Psychology", "Visual Design"],
    publishedAt: "2024-10-15",
    readingTime: 7,
    featured: false
  },
  {
    id: 5,
    title: "Responsive Design in 2024",
    excerpt: "Modern approaches to creating fluid, adaptive layouts that work across all devices and screen sizes.",
    content: "Responsive design has evolved far beyond simple breakpoints. Today's web requires thinking about fluid typography, container queries...",
    category: "Process",
    tags: ["Responsive Design", "CSS", "Mobile First"],
    publishedAt: "2024-10-01",
    readingTime: 10,
    featured: true
  },
  {
    id: 6,
    title: "Animation That Enhances UX",
    excerpt: "Using motion design thoughtfully to improve usability rather than just adding visual flair.",
    content: "Animation in UI design serves a purpose beyond aesthetics. When done right, it guides users, provides feedback...",
    category: "User Experience",
    tags: ["Animation", "Micro-interactions", "UX"],
    publishedAt: "2024-09-15",
    readingTime: 6,
    featured: false
  }
];

export type StaticBlogPost = typeof STATIC_BLOG_POSTS[0];