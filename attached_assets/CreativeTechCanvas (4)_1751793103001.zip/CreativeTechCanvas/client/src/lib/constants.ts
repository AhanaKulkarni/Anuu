export const PROJECT_TYPES = [
  { value: "ui-ux", label: "UI/UX Design" },
  { value: "development", label: "Frontend Development" },
  { value: "scriptwriting", label: "Scriptwriting" },
  { value: "creative-direction", label: "Creative Direction" },
  { value: "full-project", label: "Complete Project" },
] as const;

export const BUDGET_RANGES = [
  { value: "5k-25k", label: "₹5,000 - ₹25,000" },
  { value: "25k-75k", label: "₹25,000 - ₹75,000" },
  { value: "75k-150k", label: "₹75,000 - ₹1,50,000" },
  { value: "150k-300k", label: "₹1,50,000 - ₹3,00,000" },
  { value: "300k-500k", label: "₹3,00,000 - ₹5,00,000" },
] as const;

export const PORTFOLIO_CATEGORIES = [
  { value: "all", label: "All Projects" },
  { value: "ui-ux", label: "UI/UX Design" },
  { value: "development", label: "Development" },
  { value: "scriptwriting", label: "Scriptwriting" },
] as const;

export const SOCIAL_LINKS = [
  {
    label: "LinkedIn",
    url: "https://www.linkedin.com/in/ahana-kulkarni-753939272/",
    icon: "fab fa-linkedin"
  },
  {
    label: "Instagram", 
    url: "https://www.instagram.com/ahanapk/?hl=en",
    icon: "fab fa-instagram"
  },
  {
    label: "GitHub",
    url: "https://github.com/AhanaKulkarni", 
    icon: "fab fa-github"
  },
  {
    label: "WhatsApp",
    url: "https://wa.me/918928352406",
    icon: "fab fa-whatsapp"
  },
  {
    label: "Email",
    url: "mailto:ahanapk2319@gmail.com",
    icon: "fas fa-envelope"
  }
] as const;

export const SERVICES = [
  {
    title: "UI/UX Design",
    description: "Creating intuitive, user-centered designs that balance aesthetics with functionality. I focus on understanding your users and crafting experiences that feel natural and engaging.",
    icon: "fas fa-palette",
    color: "accent",
    features: ["User Research & Testing", "Figma Prototyping", "Design Systems", "Responsive Design"]
  },
  {
    title: "Frontend Development",
    description: "Building modern, responsive websites and applications using the latest technologies. Clean code, smooth performance, and seamless user interactions are my priorities.",
    icon: "fas fa-code",
    color: "gold",
    features: ["React.js & TypeScript", "Performance Optimization", "Mobile-First Approach", "SEO & Accessibility"]
  },
  {
    title: "Story & Scriptwriting",
    description: "Crafting compelling narratives for films, digital content, and brand storytelling. Whether it's a screenplay or marketing content, I help bring your vision to life.",
    icon: "fas fa-film",
    color: "accent",
    features: ["Film & Series Scripts", "Brand Storytelling", "Marathi & English Content", "Creative Direction"]
  }
] as const;

export const ADDITIONAL_SERVICES = [
  {
    title: "Creative Direction",
    description: "Art-led concepts and brand strategy",
    icon: "fas fa-lightbulb"
  },
  {
    title: "Webflow Development",
    description: "No-code website development",
    icon: "fas fa-mobile-alt"
  },
  {
    title: "Design Reels",
    description: "Motion graphics and animations",
    icon: "fas fa-video"
  },
  {
    title: "Collaboration",
    description: "Team projects and partnerships",
    icon: "fas fa-users"
  }
] as const;

// Static portfolio data
export const PORTFOLIO_PROJECTS = [
  {
    id: 1,
    title: "Spacify",
    description: "WebAR Interior Design Platform enabling users to visualize furniture in their space using cutting-edge AR technology and 3D rendering.",
    category: "development",
    imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["React", "R3F", "AR.js", "@react-three/xr", "Firebase", "Zustand", "Tailwind", "Vercel"],
    projectUrl: "https://github.com/AhanaKulkarni/Spacify-2",
    featured: 1
  },
  {
    id: 2,
    title: "SAKSHAM Portal",
    description: "Comprehensive academic portal featuring syllabus management, file uploads, and dynamic student progress tracking with real-time analytics.",
    category: "development",
    imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["React", "Firebase", "Node.js", "Express", "Tailwind", "Vercel"],
    projectUrl: "https://github.com/AhanaKulkarni/SakshamFinal",
    featured: 1
  },
  {
    id: 3,
    title: "Aetheron.ai Website",
    description: "Futuristic, modular website with fast-loading architecture, sophisticated animations, and clean UX for an AI company.",
    category: "development",
    imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["React", "Tailwind", "Framer Motion", "GSAP", "Three.js", "Vite"],
    projectUrl: "https://www.aetheronai.online/",
    featured: 1
  },
  {
    id: 4,
    title: "Online Clothing Store UI",
    description: "Animated shopping interface with sophisticated filter system and seamless user flow, optimized for conversion.",
    category: "ui-ux",
    imageUrl: "https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["Figma", "Prototyping", "Animation", "User Flow"],
    projectUrl: "https://www.figma.com/design/7kaW3sUw1yPwagadNjcszm/Proj-3?node-id=2-2&t=MNBSLtKy4nJ2WoW5-1",
    featured: 0
  },
  {
    id: 5,
    title: "Rotating Can UI",
    description: "Interactive 3D-style flavor switching interface with smooth animations and engaging micro-interactions.",
    category: "ui-ux",
    imageUrl: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["Figma", "3D Design", "Animation", "Interaction Design"],
    projectUrl: "https://www.figma.com/design/rIaJLJCDolc8BW7nAvgdHs/cannister-project?node-id=0-1&t=vaSRCAf1lA37p55B-1",
    featured: 0
  },
  {
    id: 6,
    title: "Cook-Keys Recipe Platform",
    description: "Modular recipe and blog UI with advanced filtering system and intuitive content organization.",
    category: "ui-ux",
    imageUrl: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["Figma", "UI Design", "Content Strategy", "Filter Systems"],
    projectUrl: "https://www.figma.com/design/v0SszCC0z1R4wrgPHOhGIV/Proj-4?node-id=1-296&t=nvf0oQW4ib0XeGx5-1",
    featured: 0
  },
  {
    id: 7,
    title: "PulseFit App",
    description: "Fitness tracker prototype developed for HackConquest, featuring comprehensive health monitoring and progress visualization.",
    category: "ui-ux",
    imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["Figma", "Prototyping", "Health Tech", "Data Visualization"],
    projectUrl: "https://www.figma.com/design/riIZRmRsBPI0dF6fDAbegt/wha?node-id=0-1&t=FZOcd0YcGLw3YBQR-1",
    featured: 0
  },
  {
    id: 8,
    title: "AXIOS E-Cell Branding",
    description: "Complete brand identity design including logo creation and comprehensive visual identity system for entrepreneurship cell.",
    category: "branding",
    imageUrl: "https://images.unsplash.com/photo-1634942537034-2531766767d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    technologies: ["Adobe Illustrator", "Photoshop", "Brand Strategy", "Visual Identity"],
    projectUrl: "https://www.instagram.com/tcet_axios_ecell?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==",
    featured: 0
  }
] as const;

export type PortfolioProject = typeof PORTFOLIO_PROJECTS[number];



