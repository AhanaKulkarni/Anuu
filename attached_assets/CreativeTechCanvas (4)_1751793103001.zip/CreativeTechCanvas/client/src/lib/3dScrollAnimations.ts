import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function init3DScrollAnimations() {
  // 3D Portfolio Cards with Depth and Rotation
  gsap.utils.toArray(".portfolio-3d-card").forEach((card: any, index) => {
    // Initial state
    gsap.set(card, {
      rotationY: 45,
      rotationX: 10,
      z: -100,
      opacity: 0,
      scale: 0.8,
    });

    // 3D entrance animation
    gsap.to(card, {
      rotationY: 0,
      rotationX: 0,
      z: 0,
      opacity: 1,
      scale: 1,
      duration: 1.2,
      ease: "power3.out",
      delay: index * 0.2,
      scrollTrigger: {
        trigger: card,
        start: "top 85%",
        end: "bottom 15%",
        toggleActions: "play none none reverse"
      }
    });

    // Continuous 3D hover effects
    card.addEventListener('mouseenter', () => {
      gsap.to(card, {
        rotationY: -8,
        rotationX: 5,
        z: 50,
        scale: 1.05,
        duration: 0.6,
        ease: "power2.out"
      });
    });

    card.addEventListener('mouseleave', () => {
      gsap.to(card, {
        rotationY: 0,
        rotationX: 0,
        z: 0,
        scale: 1,
        duration: 0.6,
        ease: "power2.out"
      });
    });

    // Scroll-based 3D transformation
    gsap.to(card, {
      rotationY: -15,
      z: -50,
      scrollTrigger: {
        trigger: card,
        start: "top center",
        end: "bottom center",
        scrub: 1,
        onUpdate: (self) => {
          const progress = self.progress;
          gsap.set(card, {
            rotationY: -15 * progress,
            z: -50 * progress,
          });
        }
      }
    });
  });

  // Floating 3D Tech Stack Icons
  gsap.utils.toArray(".tech-icon-3d").forEach((icon: any, index) => {
    gsap.set(icon, {
      z: Math.random() * 100 - 50,
      rotationY: Math.random() * 360,
      rotationX: Math.random() * 45,
    });

    gsap.to(icon, {
      y: Math.random() * 20 - 10,
      rotationY: `+=${360}`,
      duration: 4 + Math.random() * 2,
      repeat: -1,
      yoyo: true,
      ease: "power1.inOut",
      delay: index * 0.3
    });

    // Interactive depth on hover
    icon.addEventListener('mouseenter', () => {
      gsap.to(icon, {
        z: 100,
        scale: 1.3,
        rotationY: "+=180",
        duration: 0.5,
        ease: "back.out(1.7)"
      });
    });

    icon.addEventListener('mouseleave', () => {
      gsap.to(icon, {
        z: Math.random() * 100 - 50,
        scale: 1,
        duration: 0.5,
        ease: "power2.out"
      });
    });
  });

  // 3D Text Reveal with Depth
  gsap.utils.toArray(".text-3d-reveal").forEach((text: any) => {
    const chars = text.textContent.split("");
    text.innerHTML = chars.map((char: string, i: number) => 
      `<span class="char-3d" style="display: inline-block; transform-style: preserve-3d;">${char === ' ' ? '&nbsp;' : char}</span>`
    ).join("");

    const charElements = text.querySelectorAll(".char-3d");
    
    gsap.set(charElements, {
      rotationX: 90,
      z: -200,
      opacity: 0
    });

    gsap.to(charElements, {
      rotationX: 0,
      z: 0,
      opacity: 1,
      duration: 0.8,
      stagger: 0.05,
      ease: "back.out(1.7)",
      scrollTrigger: {
        trigger: text,
        start: "top 80%",
        toggleActions: "play none none reverse"
      }
    });
  });

  // Advanced 3D Portfolio Grid Animation
  const portfolioGrid = document.querySelector(".portfolio-3d-grid");
  if (portfolioGrid) {
    gsap.set(portfolioGrid, {
      perspective: 1000,
      transformStyle: "preserve-3d"
    });

    // Grid entrance with wave effect
    gsap.utils.toArray(".portfolio-3d-grid .portfolio-card").forEach((card: any, index) => {
      const row = Math.floor(index / 3);
      const col = index % 3;
      
      gsap.set(card, {
        rotationY: 180,
        z: -300,
        opacity: 0,
        transformOrigin: "center center"
      });

      gsap.to(card, {
        rotationY: 0,
        z: 0,
        opacity: 1,
        duration: 1,
        delay: (row * 0.2) + (col * 0.1),
        ease: "power3.out",
        scrollTrigger: {
          trigger: portfolioGrid,
          start: "top 70%",
          toggleActions: "play none none reverse"
        }
      });
    });
  }

  // 3D Parallax Layers
  gsap.utils.toArray(".parallax-3d-layer").forEach((layer: any, index) => {
    const depth = (index + 1) * 50;
    
    gsap.to(layer, {
      z: -depth,
      scrollTrigger: {
        trigger: layer,
        start: "top bottom",
        end: "bottom top",
        scrub: 1,
        onUpdate: (self) => {
          const progress = self.progress;
          gsap.set(layer, {
            z: -depth * (1 - progress),
            rotationY: progress * 10
          });
        }
      }
    });
  });

  // Interactive 3D Project Preview
  gsap.utils.toArray(".project-3d-preview").forEach((preview: any) => {
    const mockup = preview.querySelector(".project-mockup");
    const details = preview.querySelector(".project-details");
    
    if (mockup && details) {
      gsap.set(mockup, {
        rotationY: -25,
        z: 100,
        transformOrigin: "right center"
      });

      gsap.set(details, {
        rotationY: 25,
        z: -50,
        transformOrigin: "left center"
      });

      preview.addEventListener('mouseenter', () => {
        const tl = gsap.timeline();
        tl.to(mockup, {
          rotationY: -5,
          z: 150,
          duration: 0.6,
          ease: "power2.out"
        })
        .to(details, {
          rotationY: 5,
          z: 0,
          duration: 0.6,
          ease: "power2.out"
        }, "-=0.6");
      });

      preview.addEventListener('mouseleave', () => {
        const tl = gsap.timeline();
        tl.to(mockup, {
          rotationY: -25,
          z: 100,
          duration: 0.6,
          ease: "power2.out"
        })
        .to(details, {
          rotationY: 25,
          z: -50,
          duration: 0.6,
          ease: "power2.out"
        }, "-=0.6");
      });
    }
  });

  // 3D Scroll Progress Indicator
  const scrollIndicator = document.querySelector(".scroll-progress-3d");
  if (scrollIndicator) {
    gsap.set(scrollIndicator, {
      transformStyle: "preserve-3d",
      perspective: 500
    });

    ScrollTrigger.create({
      trigger: "body",
      start: "top top",
      end: "bottom bottom",
      onUpdate: (self) => {
        const progress = self.progress;
        gsap.set(scrollIndicator, {
          rotationX: progress * 360,
          rotationY: progress * 180,
          scale: 1 + (progress * 0.5)
        });
      }
    });
  }

  // Blog Card 3D Effects
  gsap.utils.toArray(".blog-card-3d").forEach((card: any, index) => {
    gsap.set(card, {
      rotationX: 20,
      z: -80,
      opacity: 0.8,
      transformStyle: "preserve-3d"
    });

    gsap.to(card, {
      rotationX: 0,
      z: 0,
      opacity: 1,
      duration: 1,
      delay: index * 0.15,
      ease: "power3.out",
      scrollTrigger: {
        trigger: card,
        start: "top 85%",
        toggleActions: "play none none reverse"
      }
    });

    // 3D hover interaction
    card.addEventListener('mouseenter', () => {
      gsap.to(card, {
        rotationX: -5,
        rotationY: 10,
        z: 60,
        duration: 0.5,
        ease: "power2.out"
      });
    });

    card.addEventListener('mouseleave', () => {
      gsap.to(card, {
        rotationX: 0,
        rotationY: 0,
        z: 0,
        duration: 0.5,
        ease: "power2.out"
      });
    });
  });
}

// Enhanced 3D Mouse Follow Effect
export function init3DMouseFollow() {
  let mouseX = 0;
  let mouseY = 0;

  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth) * 2 - 1;
    mouseY = (e.clientY / window.innerHeight) * 2 - 1;
  });

  gsap.utils.toArray(".mouse-3d-follow").forEach((element: any) => {
    gsap.to(element, {
      rotationY: mouseX * 15,
      rotationX: -mouseY * 15,
      duration: 2,
      ease: "power2.out",
      repeat: -1,
      onUpdate: () => {
        gsap.set(element, {
          rotationY: mouseX * 15,
          rotationX: -mouseY * 15
        });
      }
    });
  });
}

// Initialize all 3D animations
export function initializeAll3DAnimations() {
  // Set global 3D properties
  gsap.set("body", {
    transformStyle: "preserve-3d",
    perspective: 1000
  });

  init3DScrollAnimations();
  init3DMouseFollow();

  // Add CSS for 3D hardware acceleration
  const style = document.createElement('style');
  style.textContent = `
    .portfolio-3d-card,
    .tech-icon-3d,
    .blog-card-3d,
    .mouse-3d-follow {
      transform-style: preserve-3d;
      backface-visibility: hidden;
      will-change: transform;
    }
    
    .portfolio-3d-grid {
      transform-style: preserve-3d;
      perspective: 1000px;
    }
  `;
  document.head.appendChild(style);
}