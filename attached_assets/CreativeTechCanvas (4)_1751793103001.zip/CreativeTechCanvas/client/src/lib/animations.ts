import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { TextPlugin } from "gsap/TextPlugin";

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger, TextPlugin);

// Initialize animations when page loads
export function initializeAnimations() {
  // Hero section animations
  initHeroAnimations();
  
  // Section reveal animations
  initSectionRevealAnimations();
}

function initHeroAnimations() {
  const tl = gsap.timeline();
  
  // Check if elements exist before animating
  const heroBadge = document.querySelector(".hero-badge");
  const heroTitle = document.querySelector(".hero-title");
  const heroSubtitle = document.querySelector(".hero-subtitle");
  const heroDescription = document.querySelector(".hero-description");
  const heroStats = document.querySelector(".hero-stats");
  const heroButtons = document.querySelector(".hero-buttons");
  const heroSocial = document.querySelector(".hero-social");
  const heroImage = document.querySelector(".hero-image");

  // Animate hero content on load - only if elements exist
  if (heroBadge) {
    tl.fromTo(".hero-badge", 
      { opacity: 0, y: 30, scale: 0.9 },
      { opacity: 1, y: 0, scale: 1, duration: 0.8, ease: "back.out(1.7)" }
    );
  }
  
  if (heroTitle) {
    tl.fromTo(".hero-title", 
      { opacity: 0, x: -50 },
      { opacity: 1, x: 0, duration: 1, ease: "power3.out" },
      "-=0.5"
    );
  }
  
  if (heroSubtitle) {
    tl.fromTo(".hero-subtitle", 
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.8, ease: "power2.out" },
      "-=0.7"
    );
  }
  
  if (heroDescription) {
    tl.fromTo(".hero-description", 
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.8, ease: "power2.out" },
      "-=0.6"
    );
  }
  
  if (heroStats) {
    tl.fromTo(".hero-stats", 
      { opacity: 0, y: 30, stagger: 0.1 },
      { opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: "power2.out" },
      "-=0.4"
    );
  }
  
  if (heroButtons) {
    tl.fromTo(".hero-buttons", 
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.8, ease: "power2.out" },
      "-=0.3"
    );
  }
  
  if (heroSocial) {
    tl.fromTo(".hero-social", 
      { opacity: 0, x: -20, stagger: 0.1 },
      { opacity: 1, x: 0, duration: 0.5, stagger: 0.1, ease: "power2.out" },
      "-=0.2"
    );
  }

  // Floating animation for hero image - only if exists
  if (heroImage) {
    gsap.to(".hero-image", {
      y: -10,
      duration: 2,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });
  }

  // Parallax effect for floating particles
  const floatingParticles = document.querySelector(".floating-particles");
  if (floatingParticles) {
    gsap.to(".floating-particles", {
      yPercent: -30,
      ease: "none",
      scrollTrigger: {
        trigger: ".hero-section",
        start: "top bottom",
        end: "bottom top",
        scrub: true
      }
    });
  }
}

function initSectionRevealAnimations() {
  // Animate sections as they come into view
  gsap.utils.toArray(".section-reveal").forEach((section: any) => {
    if (section) {
      gsap.fromTo(section, 
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }
  });

  // Stagger animation for section content
  gsap.utils.toArray(".stagger-item").forEach((container: any) => {
    if (container) {
      const children = container.querySelectorAll(".stagger-child");
      if (children.length > 0) {
        gsap.fromTo(children,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: "power2.out",
            scrollTrigger: {
              trigger: container,
              start: "top 80%",
              toggleActions: "play none none reverse"
            }
          }
        );
      }
    }
  });
}

// Page transition animation
export function animatePageTransition() {
  const tl = gsap.timeline();
  
  tl.to("main", {
    opacity: 0,
    y: -20,
    duration: 0.3,
    ease: "power2.in"
  })
  .set("main", { y: 20 })
  .to("main", {
    opacity: 1,
    y: 0,
    duration: 0.5,
    ease: "power2.out"
  });
}

// Mobile menu animations
export function showMobileMenu() {
  const menu = document.querySelector(".mobile-menu");
  if (menu) {
    gsap.fromTo(menu, 
      { opacity: 0, x: "100%" },
      { opacity: 1, x: "0%", duration: 0.3, ease: "power2.out" }
    );
  }
}

export function hideMobileMenu() {
  const menu = document.querySelector(".mobile-menu");
  if (menu) {
    gsap.to(menu, {
      opacity: 0,
      x: "100%",
      duration: 0.3,
      ease: "power2.in"
    });
  }
}

// Mouse follower animation
export function initMouseFollower() {
  const cursor = document.querySelector(".animated-cursor");
  if (cursor) {
    document.addEventListener("mousemove", (e) => {
      gsap.to(cursor, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.3,
        ease: "power2.out"
      });
    });
  }
}

// Scroll progress indicator
export function initScrollProgress() {
  const progressBar = document.querySelector(".scroll-indicator");
  if (progressBar) {
    gsap.to(progressBar, {
      scaleX: 1,
      ease: "none",
      scrollTrigger: {
        trigger: "body",
        start: "top top",
        end: "bottom bottom",
        scrub: true
      }
    });
  }
}