import { gsap } from "gsap";

// 3D Tilt Effect for Cards
export function initTiltEffect() {
  const cards = document.querySelectorAll('.tilt-card');
  
  cards.forEach((card: any) => {
    card.addEventListener('mousemove', (e: MouseEvent) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const rotateX = (y - centerY) / centerY * -10;
      const rotateY = (x - centerX) / centerX * 10;
      
      gsap.to(card, {
        duration: 0.3,
        rotationX: rotateX,
        rotationY: rotateY,
        transformPerspective: 1000,
        ease: "power2.out"
      });
    });
    
    card.addEventListener('mouseleave', () => {
      gsap.to(card, {
        duration: 0.5,
        rotationX: 0,
        rotationY: 0,
        ease: "power2.out"
      });
    });
  });
}

// Magnetic Button Effect
export function initMagneticButtons() {
  const buttons = document.querySelectorAll('.magnetic-button');
  
  buttons.forEach((button: any) => {
    button.addEventListener('mousemove', (e: MouseEvent) => {
      const rect = button.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      
      gsap.to(button, {
        duration: 0.3,
        x: x * 0.3,
        y: y * 0.3,
        ease: "power2.out"
      });
    });
    
    button.addEventListener('mouseleave', () => {
      gsap.to(button, {
        duration: 0.5,
        x: 0,
        y: 0,
        ease: "elastic.out(1, 0.3)"
      });
    });
  });
}

// Parallax Scroll Effect
export function initParallax() {
  const parallaxElements = document.querySelectorAll('.parallax-element');
  
  parallaxElements.forEach((element: any) => {
    gsap.to(element, {
      yPercent: -30,
      ease: "none",
      scrollTrigger: {
        trigger: element,
        start: "top bottom",
        end: "bottom top",
        scrub: true
      }
    });
  });
}

// Interactive Hover Animations
export function initHoverAnimations() {
  // Service card animations
  const serviceCards = document.querySelectorAll('.service-card');
  
  serviceCards.forEach((card: any) => {
    const icon = card.querySelector('i');
    const title = card.querySelector('h3');
    
    card.addEventListener('mouseenter', () => {
      gsap.to(card, {
        y: -15,
        boxShadow: "0 25px 50px rgba(0,0,0,0.15)",
        duration: 0.4,
        ease: "power3.out"
      });
      
      gsap.to(icon, {
        scale: 1.2,
        rotation: 360,
        duration: 0.6,
        ease: "back.out(1.7)"
      });
      
      gsap.to(title, {
        scale: 1.05,
        duration: 0.3,
        ease: "power2.out"
      });
    });
    
    card.addEventListener('mouseleave', () => {
      gsap.to(card, {
        y: 0,
        boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
        duration: 0.4,
        ease: "power3.out"
      });
      
      gsap.to(icon, {
        scale: 1,
        rotation: 0,
        duration: 0.4,
        ease: "power2.out"
      });
      
      gsap.to(title, {
        scale: 1,
        duration: 0.3,
        ease: "power2.out"
      });
    });
  });
}

// Enhanced Button Ripple Effect
export function initRippleEffect() {
  const buttons = document.querySelectorAll('.animated-button');
  
  buttons.forEach((button: any) => {
    button.addEventListener('click', (e: MouseEvent) => {
      const rect = button.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;
      
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      
      button.appendChild(ripple);
      
      gsap.fromTo(ripple,
        { scale: 0, opacity: 1 },
        { 
          scale: 2, 
          opacity: 0, 
          duration: 0.6, 
          ease: "power2.out",
          onComplete: () => ripple.remove()
        }
      );
    });
  });
}

// Floating Animation for Hero Elements
export function initFloatingElements() {
  const floatingElements = document.querySelectorAll('.floating-element');
  
  floatingElements.forEach((element: any, index) => {
    gsap.to(element, {
      y: Math.random() * 20 - 10,
      x: Math.random() * 10 - 5,
      rotation: Math.random() * 10 - 5,
      duration: 3 + Math.random() * 2,
      repeat: -1,
      yoyo: true,
      ease: "power1.inOut",
      delay: index * 0.5
    });
  });
}

// Advanced Scroll Animations
export function initAdvancedScrollAnimations() {
  // Reveal animations with different easing
  gsap.utils.toArray('.reveal-up').forEach((element: any) => {
    gsap.fromTo(element,
      { y: 100, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: "back.out(1.7)",
        scrollTrigger: {
          trigger: element,
          start: "top 80%",
          toggleActions: "play none none reverse"
        }
      }
    );
  });
  
  gsap.utils.toArray('.reveal-left').forEach((element: any) => {
    gsap.fromTo(element,
      { x: -100, opacity: 0 },
      {
        x: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: element,
          start: "top 80%",
          toggleActions: "play none none reverse"
        }
      }
    );
  });
  
  gsap.utils.toArray('.reveal-right').forEach((element: any) => {
    gsap.fromTo(element,
      { x: 100, opacity: 0 },
      {
        x: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: element,
          start: "top 80%",
          toggleActions: "play none none reverse"
        }
      }
    );
  });
}

// Initialize all interactive effects
export function initAllInteractiveEffects() {
  // Wait for DOM to be ready
  document.addEventListener('DOMContentLoaded', () => {
    initTiltEffect();
    initMagneticButtons();
    initParallax();
    initHoverAnimations();
    initRippleEffect();
    initFloatingElements();
    initAdvancedScrollAnimations();
  });
  
  // Also run immediately if DOM is already loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(() => {
        initTiltEffect();
        initMagneticButtons();
        initParallax();
        initHoverAnimations();
        initRippleEffect();
        initFloatingElements();
        initAdvancedScrollAnimations();
      }, 100);
    });
  } else {
    setTimeout(() => {
      initTiltEffect();
      initMagneticButtons();
      initParallax();
      initHoverAnimations();
      initRippleEffect();
      initFloatingElements();
      initAdvancedScrollAnimations();
    }, 100);
  }
}