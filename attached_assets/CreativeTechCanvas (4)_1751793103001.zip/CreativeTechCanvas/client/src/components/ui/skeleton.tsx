import { cn } from "@/lib/utils"

function Skeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-muted", className)}
      {...props}
    />
  )
}

// Enhanced animated skeleton for project cards
function ProjectCardSkeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("project-card-skeleton bg-white dark:bg-gray-800 rounded-3xl shadow-lg overflow-hidden", className)}
      {...props}
    >
      {/* Image skeleton with shimmer */}
      <div className="relative h-64 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 skeleton-shimmer"></div>
      
      <div className="p-6 space-y-4">
        {/* Category and icon skeleton */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 skeleton-shimmer"></div>
            <div className="h-4 w-20 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-shimmer"></div>
          </div>
          <div className="w-5 h-5 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-shimmer"></div>
        </div>
        
        {/* Title skeleton */}
        <div className="space-y-2">
          <div className="h-6 w-3/4 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-shimmer"></div>
          <div className="h-6 w-1/2 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-shimmer"></div>
        </div>
        
        {/* Description skeleton */}
        <div className="space-y-2">
          <div className="h-4 w-full bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-shimmer"></div>
          <div className="h-4 w-4/5 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-shimmer"></div>
        </div>
        
        {/* Tech stack skeleton */}
        <div className="flex gap-2 flex-wrap">
          <div className="h-6 w-16 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded-full skeleton-shimmer"></div>
          <div className="h-6 w-20 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded-full skeleton-shimmer"></div>
          <div className="h-6 w-18 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded-full skeleton-shimmer"></div>
        </div>
      </div>
    </div>
  )
}

// Floating skeleton loader with 3D effects
function FloatingProjectSkeleton({
  index = 0,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { index?: number }) {
  return (
    <div
      className={cn("floating-skeleton-3d", className)}
      style={{
        animationDelay: `${index * 0.15}s`
      }}
      {...props}
    >
      <div className="floating-skeleton-inner bg-white dark:bg-gray-800 rounded-3xl shadow-2xl overflow-hidden relative">
        {/* Animated gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-[hsl(43,96%,56%)]/5 opacity-60 skeleton-pulse"></div>
        
        {/* Floating badge */}
        <div className="absolute top-4 left-4 z-10">
          <div className="w-12 h-8 bg-white/90 dark:bg-black/90 backdrop-blur-md rounded-full skeleton-float"></div>
        </div>
        
        {/* Main image area */}
        <div className="relative h-64 overflow-hidden">
          <div className="w-full h-full bg-gradient-to-br from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 skeleton-wave"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
        </div>
        
        {/* Content area */}
        <div className="p-6 space-y-4">
          {/* Header row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full skeleton-bounce bg-gradient-to-r from-accent/20 to-[hsl(43,96%,56%)]/20"></div>
              <div className="h-4 w-24 skeleton-slide bg-gradient-to-r from-accent/30 to-[hsl(43,96%,56%)]/30 rounded"></div>
            </div>
            <div className="w-5 h-5 skeleton-rotate bg-gradient-to-r from-gray-300 to-gray-400 dark:from-gray-600 dark:to-gray-500 rounded"></div>
          </div>
          
          {/* Title lines */}
          <div className="space-y-3">
            <div className="h-6 w-4/5 skeleton-expand bg-gradient-to-r from-gray-300 via-gray-400 to-gray-300 dark:from-gray-600 dark:via-gray-500 dark:to-gray-600 rounded"></div>
            <div className="h-6 w-3/5 skeleton-expand bg-gradient-to-r from-gray-300 via-gray-400 to-gray-300 dark:from-gray-600 dark:via-gray-500 dark:to-gray-600 rounded" style={{ animationDelay: '0.2s' }}></div>
          </div>
          
          {/* Description */}
          <div className="space-y-2">
            <div className="h-4 w-full skeleton-fade bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded"></div>
            <div className="h-4 w-5/6 skeleton-fade bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded" style={{ animationDelay: '0.3s' }}></div>
          </div>
          
          {/* Tech badges */}
          <div className="flex gap-2 flex-wrap">
            {[0, 1, 2].map((i) => (
              <div 
                key={i}
                className="h-7 skeleton-tech-badge bg-gradient-to-r from-accent/20 via-accent/30 to-accent/20 rounded-full"
                style={{ 
                  width: `${60 + i * 10}px`,
                  animationDelay: `${i * 0.1}s` 
                }}
              ></div>
            ))}
          </div>
        </div>
        
        {/* Bottom glow effect */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-accent/50 to-transparent skeleton-glow"></div>
      </div>
    </div>
  )
}

// Blog post skeleton with animated elements
function BlogPostSkeleton({
  index = 0,
  featured = false,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { index?: number; featured?: boolean }) {
  return (
    <div
      className={cn(
        "blog-skeleton-card group",
        featured ? "featured-blog-skeleton" : "regular-blog-skeleton",
        className
      )}
      style={{
        animationDelay: `${index * 0.1}s`
      }}
      {...props}
    >
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden h-full relative">
        {/* Animated background overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-accent/3 to-[hsl(43,96%,56%)]/3 opacity-60 skeleton-pulse"></div>
        
        {/* Category badge skeleton */}
        <div className="absolute top-4 left-4 z-10">
          <div className="h-6 w-24 bg-accent/20 rounded-full skeleton-shimmer"></div>
        </div>
        
        {/* Featured badge for featured posts */}
        {featured && (
          <div className="absolute top-4 right-4 z-10">
            <div className="h-6 w-20 bg-[hsl(43,96%,56%)]/20 rounded-full skeleton-float"></div>
          </div>
        )}
        
        {/* Image area */}
        <div className={`relative overflow-hidden ${featured ? 'h-80' : 'h-48'}`}>
          <div className="w-full h-full bg-gradient-to-br from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 skeleton-wave"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent"></div>
        </div>
        
        {/* Content area */}
        <div className="p-6 space-y-4">
          {/* Date and read time */}
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gray-300 dark:bg-gray-600 rounded skeleton-bounce"></div>
              <div className="h-3 w-20 bg-gray-300 dark:bg-gray-600 rounded skeleton-slide"></div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gray-300 dark:bg-gray-600 rounded skeleton-bounce" style={{ animationDelay: '0.2s' }}></div>
              <div className="h-3 w-16 bg-gray-300 dark:bg-gray-600 rounded skeleton-slide" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
          
          {/* Title */}
          <div className="space-y-2">
            <div className={`${featured ? 'h-8 w-5/6' : 'h-6 w-4/5'} bg-gradient-to-r from-gray-300 via-gray-400 to-gray-300 dark:from-gray-600 dark:via-gray-500 dark:to-gray-600 rounded skeleton-expand`}></div>
            {featured && (
              <div className="h-8 w-3/4 bg-gradient-to-r from-gray-300 via-gray-400 to-gray-300 dark:from-gray-600 dark:via-gray-500 dark:to-gray-600 rounded skeleton-expand" style={{ animationDelay: '0.1s' }}></div>
            )}
          </div>
          
          {/* Description */}
          <div className="space-y-2">
            <div className="h-4 w-full bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-fade"></div>
            <div className="h-4 w-5/6 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-fade" style={{ animationDelay: '0.2s' }}></div>
            {featured && (
              <div className="h-4 w-4/5 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 dark:from-gray-700 dark:via-gray-600 dark:to-gray-700 rounded skeleton-fade" style={{ animationDelay: '0.4s' }}></div>
            )}
          </div>
          
          {/* Read more button */}
          <div className="pt-2">
            <div className="h-10 w-32 bg-gradient-to-r from-accent/20 via-accent/30 to-accent/20 rounded-full skeleton-tech-badge"></div>
          </div>
        </div>
        
        {/* Bottom accent line */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-accent/40 to-transparent skeleton-glow"></div>
      </div>
    </div>
  )
}

export { Skeleton, ProjectCardSkeleton, FloatingProjectSkeleton, BlogPostSkeleton }
