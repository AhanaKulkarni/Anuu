import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { SOCIAL_LINKS } from "@/lib/constants";

const navigationItems = [
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/portfolio", label: "Portfolio" },
  { href: "/blog", label: "Blog" },
  { href: "/certifications", label: "Certifications" },
  { href: "/contact", label: "Contact" },
];

export function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.body.scrollHeight - window.innerHeight;
      const progress = window.pageYOffset / totalHeight;
      setScrollProgress(progress);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isActive = (href: string) => {
    return location === href;
  };

  return (
    <>
      {/* Scroll Progress Indicator */}
      <div 
        className="scroll-indicator"
        style={{ transform: `scaleX(${scrollProgress})` }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 dark:bg-black/80 dark:border-gray-800 card-stack">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="font-space font-bold text-xl text-primary">
              Ahana <span className="holographic-text" data-text="Kulkarni">Kulkarni</span>
            </div>
            
            <div className="hidden md:flex space-x-8">
              {navigationItems.map((item, index) => (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item.href)}
                  className="text-primary hover:text-accent transition-all duration-300 dark:text-white dark:hover:text-accent transform hover:scale-105 relative z-10"
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'scale(1.05) translateZ(5px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'scale(1) translateZ(0px)';
                  }}
                >
                  {item.label}
                </button>
              ))}
            </div>
            
            <div className="hidden md:flex items-center gap-3">
              <ThemeToggle />
              <Button 
                onClick={() => handleNavClick("#contact")}
                className="liquid-button text-white px-6 py-2 rounded-full transition-all duration-300 transform hover:scale-105 relative z-10"
              >
                <span className="relative z-20">Hire Me</span>
              </Button>
            </div>
            
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              className="md:hidden p-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
            </Button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 dark:bg-black dark:border-gray-800">
            <div className="px-6 py-4 space-y-4">
              {navigationItems.map((item) => (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item.href)}
                  className="block text-primary hover:text-accent transition-colors dark:text-white dark:hover:text-accent"
                >
                  {item.label}
                </button>
              ))}
              <div className="flex items-center gap-3 mt-4">
                <ThemeToggle />
                <Button 
                  onClick={() => handleNavClick("#contact")}
                  className="bg-accent text-white px-6 py-2 rounded-full"
                >
                  Hire Me
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
