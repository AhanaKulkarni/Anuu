import { useEffect, useRef, useState } from 'react';

export function AnimatedCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const followerRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Don't show cursor on mobile
    if (window.innerWidth <= 768) return;

    const cursor = cursorRef.current;
    const follower = followerRef.current;
    
    if (!cursor || !follower) return;

    let mouseX = 0;
    let mouseY = 0;
    let followerX = 0;
    let followerY = 0;
    let animationId: number;

    // Hide default cursor and show custom cursor
    document.body.style.cursor = 'none';
    setIsVisible(true);

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      
      cursor.style.left = mouseX + 'px';
      cursor.style.top = mouseY + 'px';
      cursor.style.opacity = '1';
    };

    const updateFollower = () => {
      followerX += (mouseX - followerX) * 0.1;
      followerY += (mouseY - followerY) * 0.1;
      
      follower.style.left = followerX + 'px';
      follower.style.top = followerY + 'px';
      follower.style.opacity = '1';
      
      animationId = requestAnimationFrame(updateFollower);
    };

    const handleMouseEnter = (e: Event) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'A' || target.tagName === 'BUTTON' || target.getAttribute('role') === 'button')) {
        cursor.style.transform = 'translate(-50%, -50%) scale(0.5)';
        follower.style.transform = 'translate(-50%, -50%) scale(2)';
        follower.style.borderColor = 'rgba(108, 99, 255, 0.8)';
      }
    };

    const handleMouseLeave = (e: Event) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'A' || target.tagName === 'BUTTON' || target.getAttribute('role') === 'button')) {
        cursor.style.transform = 'translate(-50%, -50%) scale(1)';
        follower.style.transform = 'translate(-50%, -50%) scale(1)';
        follower.style.borderColor = 'rgba(108, 99, 255, 0.3)';
      }
    };

    // Initialize cursor position
    cursor.style.left = '50%';
    cursor.style.top = '50%';
    follower.style.left = '50%';
    follower.style.top = '50%';

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseenter', handleMouseEnter, true);
    document.addEventListener('mouseleave', handleMouseLeave, true);
    
    updateFollower();

    return () => {
      document.body.style.cursor = 'auto';
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseenter', handleMouseEnter, true);
      document.removeEventListener('mouseleave', handleMouseLeave, true);
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
      setIsVisible(false);
    };
  }, []);

  // Don't render on mobile or if not visible
  if (typeof window !== 'undefined' && (window.innerWidth <= 768 || !isVisible)) {
    return null;
  }

  return (
    <>
      {/* Main cursor */}
      <div
        ref={cursorRef}
        style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          width: '12px',
          height: '12px',
          backgroundColor: 'hsl(239, 84%, 67%)',
          borderRadius: '50%',
          transform: 'translate(-50%, -50%)',
          zIndex: 999999,
          pointerEvents: 'none',
          opacity: 0,
          mixBlendMode: 'difference',
          transition: 'transform 0.3s ease'
        }}
      />
      
      {/* Follower cursor */}
      <div
        ref={followerRef}
        style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          width: '32px',
          height: '32px',
          border: '2px solid rgba(108, 99, 255, 0.3)',
          borderRadius: '50%',
          transform: 'translate(-50%, -50%)',
          zIndex: 999998,
          pointerEvents: 'none',
          opacity: 0,
          transition: 'transform 0.3s ease, border-color 0.3s ease'
        }}
      />
    </>
  );
}