export function SkillsSection() {
  const skillCategories = [
    {
      title: "Design & Creative",
      icon: "fas fa-palette",
      skills: [
        { name: "UI/UX Design", level: 95 },
        { name: "Figma", level: 90 },
        { name: "Webflow", level: 85 },
        { name: "Adobe Creative Suite", level: 80 },
        { name: "Canva", level: 90 },
        { name: "Design Systems", level: 88 }
      ]
    },
    {
      title: "Development",
      icon: "fas fa-code",
      skills: [
        { name: "HTML/CSS", level: 95 },
        { name: "JavaScript", level: 90 },
        { name: "React.js", level: 85 },
        { name: "TypeScript", level: 80 },
        { name: "Node.js", level: 75 },
        { name: "Responsive Design", level: 95 }
      ]
    },
    {
      title: "Storytelling & Content",
      icon: "fas fa-film",
      skills: [
        { name: "Scriptwriting", level: 90 },
        { name: "Marathi Scripts", level: 95 },
        { name: "English Scripts", level: 85 },
        { name: "Ad Storytelling", level: 80 },
        { name: "Creative Direction", level: 85 },
        { name: "Content Strategy", level: 75 }
      ]
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-black">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-accent font-medium text-lg">Skills & Expertise</span>
          <h2 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6">
            Technical <span className="gradient-text">Proficiency</span>
          </h2>
          <p className="text-neutral text-xl max-w-3xl mx-auto">
            A comprehensive skill set spanning design, development, and storytelling
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div key={category.title} className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className="bg-accent/10 w-12 h-12 rounded-2xl flex items-center justify-center mr-4">
                  <i className={`${category.icon} text-accent text-xl`}></i>
                </div>
                <h3 className="font-space font-bold text-xl">{category.title}</h3>
              </div>
              
              <div className="space-y-4">
                {category.skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{skill.name}</span>
                      <span className="text-sm text-accent font-semibold">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-accent to-[hsl(43,96%,56%)] h-2 rounded-full transition-all duration-1000 ease-out"
                        style={{ 
                          width: `${skill.level}%`,
                          animationDelay: `${index * 0.2}s` 
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Achievement Stats */}
        <div className="mt-16 bg-gradient-to-r from-accent/10 to-[hsl(43,96%,56%)]/10 p-8 rounded-3xl border border-accent/20">
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-accent mb-2">50+</div>
              <div className="text-sm text-neutral">Projects Completed</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-[hsl(43,96%,56%)] mb-2">3+</div>
              <div className="text-sm text-neutral">Years Experience</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-accent mb-2">25+</div>
              <div className="text-sm text-neutral">Happy Clients</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-[hsl(43,96%,56%)] mb-2">5</div>
              <div className="text-sm text-neutral">Film Festivals</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}