import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton, ProjectCardSkeleton, FloatingProjectSkeleton } from "@/components/ui/skeleton";
import { ExternalLink, Github, Layers, Zap, Palette, Code, Smartphone } from "lucide-react";
import { PORTFOLIO_CATEGORIES, PORTFOLIO_PROJECTS, type PortfolioProject } from "@/lib/constants";
import { initializeAll3DAnimations } from "@/lib/3dScrollAnimations";

export function PortfolioSection() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  // Use static portfolio data
  const projects = PORTFOLIO_PROJECTS;

  const filteredProjects = projects.filter(project => 
    activeFilter === "all" || project.category === activeFilter
  );

  useEffect(() => {
    // Initialize 3D animations after component mounts
    setTimeout(() => {
      initializeAll3DAnimations();
      setIsLoading(false);
    }, 100);
  }, []);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'development': return <Code className="w-5 h-5" />;
      case 'ui-ux': return <Palette className="w-5 h-5" />;
      case 'branding': return <Layers className="w-5 h-5" />;
      default: return <Zap className="w-5 h-5" />;
    }
  };

  const getProjectTypeIcon = (title: string) => {
    if (title.includes('AR') || title.includes('3D')) return '🥽';
    if (title.includes('Portal') || title.includes('Platform')) return '🌐';
    if (title.includes('AI') || title.includes('Website')) return '🚀';
    if (title.includes('UI') || title.includes('App')) return '📱';
    if (title.includes('Brand')) return '🎨';
    return '💻';
  };

  return (
    <section id="portfolio" className="py-20 bg-white dark:bg-black">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-accent font-medium text-lg">My Work</span>
          <h2 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6 split-text">
            Featured <span className="holographic-text" data-text="Projects">Projects</span>
          </h2>
          <p className="text-neutral text-xl max-w-3xl mx-auto">
            A showcase of design, development, and storytelling projects that demonstrate creativity and technical excellence
          </p>
        </div>
        
        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {PORTFOLIO_CATEGORIES.map((category) => (
            <Button
              key={category.value}
              onClick={() => setActiveFilter(category.value)}
              variant={activeFilter === category.value ? "default" : "outline"}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                activeFilter === category.value 
                  ? "bg-accent text-white hover:bg-accent/90" 
                  : "bg-gray-200 hover:bg-gray-300 text-neutral dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-300"
              }`}
            >
              {category.label}
            </Button>
          ))}
        </div>
        
        {/* Portfolio Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" style={{ perspective: '1000px' }}>
            {Array.from({ length: 6 }).map((_, i) => (
              <FloatingProjectSkeleton key={i} index={i} />
            ))}
          </div>
        ) : (
          <div className="portfolio-3d-grid grid md:grid-cols-2 lg:grid-cols-3 gap-8" style={{ perspective: '1000px' }}>
            {filteredProjects.map((project, index) => (
              <a
                key={project.id}
                href={project.projectUrl ?? '#'}
                target="_blank"
                rel="noopener noreferrer"
                className="project-card-3d group cursor-pointer block"
                style={{
                  animationDelay: `${index * 0.1}s`
                }}
                onMouseEnter={(e) => {
                  const card = e.currentTarget;
                  const rect = card.getBoundingClientRect();
                  const centerX = rect.left + rect.width / 2;
                  const centerY = rect.top + rect.height / 2;
                  
                  const mouseX = (e.clientX - centerX) / (rect.width / 2);
                  const mouseY = (e.clientY - centerY) / (rect.height / 2);
                  
                  card.style.transform = `
                    rotateY(${mouseX * 15}deg) 
                    rotateX(${-mouseY * 15}deg) 
                    translateZ(50px)
                    scale3d(1.05, 1.05, 1.05)
                  `;
                }}
                onMouseMove={(e) => {
                  const card = e.currentTarget;
                  const rect = card.getBoundingClientRect();
                  const centerX = rect.left + rect.width / 2;
                  const centerY = rect.top + rect.height / 2;
                  
                  const mouseX = (e.clientX - centerX) / (rect.width / 2);
                  const mouseY = (e.clientY - centerY) / (rect.height / 2);
                  
                  card.style.transform = `
                    rotateY(${mouseX * 15}deg) 
                    rotateX(${-mouseY * 15}deg) 
                    translateZ(50px)
                    scale3d(1.05, 1.05, 1.05)
                  `;
                }}
                onMouseLeave={(e) => {
                  const card = e.currentTarget;
                  card.style.transform = 'rotateY(0deg) rotateX(0deg) translateZ(0px) scale3d(1, 1, 1)';
                }}
              >
                <div className="project-card-inner bg-white dark:bg-gray-800 rounded-3xl shadow-2xl overflow-hidden h-full relative card-stack">
                  {/* 3D Depth Layer */}
                  <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-[hsl(43,96%,56%)]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"></div>
                  
                  {/* Advanced Holographic Effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 transform -skew-x-12 translate-x-full group-hover:translate-x-[-200%] z-20"></div>
                  
                  {/* Matrix Rain Effect */}
                  <div className="matrix-rain opacity-0 group-hover:opacity-100 transition-opacity duration-1000">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div 
                        key={i}
                        className="matrix-column"
                        style={{
                          left: `${i * 20 + 10}%`,
                          animationDelay: `${i * 0.5}s`
                        }}
                      >
                        {Array.from({ length: 10 }).map((_, j) => (
                          <div key={j} style={{ marginBottom: '5px' }}>
                            {String.fromCharCode(65 + Math.floor(Math.random() * 26))}
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                  
                  {/* Project Type Badge */}
                  <div className="absolute top-4 left-4 z-30">
                    <div className="bg-white/90 dark:bg-black/90 backdrop-blur-md rounded-full px-3 py-1 text-2xl shadow-lg transform group-hover:scale-110 transition-transform duration-300">
                      {getProjectTypeIcon(project.title)}
                    </div>
                  </div>
                  
                  {/* Project Image with Parallax */}
                  <div className="relative overflow-hidden h-64">
                    <img 
                      src={project.imageUrl} 
                      alt={project.title}
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  </div>
                  
                  {/* Content with 3D Transform */}
                  <div className="p-6 relative z-20 transform group-hover:translateZ-20 transition-transform duration-500">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-full ${
                          project.category === 'development' ? 'bg-[hsl(43,96%,56%)]/10' : 'bg-accent/10'
                        }`}>
                          {getCategoryIcon(project.category)}
                        </div>
                        <span className={`text-sm font-medium ${
                          project.category === 'development' ? 'text-[hsl(43,96%,56%)]' : 'text-accent'
                        }`}>
                          {project.category === 'ui-ux' ? 'UI/UX Design' : 
                           project.category === 'development' ? 'Development' : 
                           'Scriptwriting'}
                        </span>
                      </div>
                      {project.projectUrl && (
                        <div className="group-hover:rotate-12 transition-transform duration-300">
                          <ExternalLink className="w-5 h-5 text-neutral hover:text-accent cursor-pointer" />
                        </div>
                      )}
                    </div>
                    
                    <h3 className="font-space font-bold text-xl mb-2 group-hover:text-accent transition-colors duration-300">
                      {project.title}
                    </h3>
                    
                    <p className="text-neutral text-sm mb-4 line-clamp-2">
                      {project.description}
                    </p>
                    
                    {/* Floating Tech Stack */}
                    <div className="flex flex-wrap gap-2">
                      {project.technologies?.slice(0, 3).map((tech, techIndex) => (
                        <span 
                          key={tech}
                          className={`text-xs px-3 py-1 rounded-full backdrop-blur-sm transform group-hover:scale-105 transition-all duration-300 ${
                            project.category === 'development' 
                              ? 'bg-[hsl(43,96%,56%)]/20 text-[hsl(43,96%,56%)] border border-[hsl(43,96%,56%)]/30' 
                              : 'bg-accent/20 text-accent border border-accent/30'
                          }`}
                          style={{
                            animationDelay: `${techIndex * 0.1}s`
                          }}
                        >
                          {tech}
                        </span>
                      ))}
                      {project.technologies && project.technologies.length > 3 && (
                        <span className="text-xs px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400">
                          +{project.technologies.length - 3}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {/* Bottom Glow Effect */}
                  <div className={`absolute bottom-0 left-0 right-0 h-1 opacity-0 group-hover:opacity-100 transition-opacity duration-500 ${
                    project.category === 'development' 
                      ? 'bg-gradient-to-r from-transparent via-[hsl(43,96%,56%)] to-transparent' 
                      : 'bg-gradient-to-r from-transparent via-accent to-transparent'
                  }`}></div>
                </div>
              </a>
            ))}
          </div>
        )}
        
        {/* View More Button */}
        <div className="text-center mt-12">
          <Button 
            onClick={() => {
              const element = document.querySelector("#contact");
              if (element) {
                element.scrollIntoView({ behavior: "smooth" });
              }
            }}
            className="magnetic-button bg-accent hover:bg-accent/90 text-white px-8 py-4 rounded-full transition-all duration-300 transform hover:scale-105 inline-flex items-center"
          >
            <span>Let's Collaborate</span>
            <ExternalLink className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}
