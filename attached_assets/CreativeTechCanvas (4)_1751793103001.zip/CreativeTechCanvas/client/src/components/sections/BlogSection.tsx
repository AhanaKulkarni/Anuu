import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Calendar, Clock, ArrowRight, BookOpen } from "lucide-react";
import { STATIC_BLOG_POSTS, type StaticBlogPost } from "@/lib/staticData";

const BLOG_CATEGORIES = [
  "All Posts",
  "Design Systems",
  "User Experience", 
  "Creative Technology",
  "Design Theory",
  "Accessibility",
  "Process"
];

export function BlogSection() {
  const [activeCategory, setActiveCategory] = useState("All Posts");
  const [visiblePosts, setVisiblePosts] = useState(6);
  const [isLoading, setIsLoading] = useState(true);

  // Use static blog data
  const blogPosts = STATIC_BLOG_POSTS;

  useEffect(() => {
    // Simulate loading state
    setTimeout(() => setIsLoading(false), 500);
  }, []);

  const filteredPosts = activeCategory === "All Posts" 
    ? blogPosts 
    : blogPosts.filter(post => post.category === activeCategory);

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const truncateContent = (content: string, maxLength: number = 150) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + "...";
  };

  if (isLoading) {
    return (
      <section id="blog" className="py-20 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-accent font-medium text-lg">Insights & Inspiration</span>
            <h2 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6">
              Latest <span className="gradient-text">Blog Posts</span>
            </h2>
            <p className="text-neutral text-xl max-w-3xl mx-auto">
              Thoughts on design, development, and the creative process behind great digital experiences.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="animate-pulse">
                <div className="bg-gray-200 dark:bg-gray-700 h-48 rounded-lg mb-4"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="blog" className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-accent font-medium text-lg">Insights & Inspiration</span>
          <h2 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6">
            Latest <span className="gradient-text">Blog Posts</span>
          </h2>
          <p className="text-neutral text-xl max-w-3xl mx-auto">
            Thoughts on design, development, and the creative process behind great digital experiences.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {BLOG_CATEGORIES.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              onClick={() => setActiveCategory(category)}
              className="rounded-full px-6 py-2"
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Blog Posts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {filteredPosts.slice(0, visiblePosts).map((post) => (
            <Card key={post.id} className="group hover:shadow-lg transition-all duration-300 border-0 bg-white dark:bg-gray-800">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between mb-3">
                  <Badge variant="secondary" className="text-xs font-medium">
                    {post.category}
                  </Badge>
                  {post.featured && (
                    <Badge variant="default" className="text-xs">
                      Featured
                    </Badge>
                  )}
                </div>
                <h3 className="text-xl font-bold group-hover:text-accent transition-colors line-clamp-2">
                  {post.title}
                </h3>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-neutral mb-4 leading-relaxed">
                  {truncateContent(post.excerpt)}
                </p>
                
                <div className="flex items-center justify-between text-sm text-neutral mb-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{formatDate(post.publishedAt)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>{post.readingTime} min read</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {post.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                
                <Button variant="ghost" className="w-full group/btn hover:bg-accent hover:text-white">
                  <span>Read Article</span>
                  <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More Button */}
        {filteredPosts.length > visiblePosts && (
          <div className="text-center">
            <Button 
              onClick={() => setVisiblePosts(prev => prev + 6)}
              variant="outline"
              size="lg"
              className="px-8 py-3 rounded-full"
            >
              <BookOpen className="w-5 h-5 mr-2" />
              Load More Articles
            </Button>
          </div>
        )}

        {/* Empty State */}
        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 text-neutral mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-semibold mb-2">No posts found</h3>
            <p className="text-neutral">Try selecting a different category or check back later for new content.</p>
          </div>
        )}
      </div>
    </section>
  );
}