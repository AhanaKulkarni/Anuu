export function AboutSection() {
  const skills = [
    "UI/UX Design", "Frontend Development", "React.js", "Figma", 
    "Webflow", "Scriptwriting", "Creative Direction"
  ];

  return (
    <section id="about" className="py-20 bg-white dark:bg-black">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-accent font-medium text-lg">About Me</span>
          <h2 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6">
            Creating <span className="gradient-text">Meaningful Impact</span>
          </h2>
          <p className="text-neutral text-xl max-w-3xl mx-auto">
            I focus on delivering creative solutions that make a real difference for businesses and their users
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Creative workspace with design tools" 
              className="rounded-2xl shadow-xl w-full"
            />
          </div>
          
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 p-6 rounded-2xl border-l-4 border-green-500">
                <h3 className="font-space font-bold text-xl mb-3 text-green-800 dark:text-green-200 flex items-center">
                  <i className="fas fa-chart-up mr-3 text-green-600"></i>
                  Improved User Experience
                </h3>
                <p className="text-green-700 dark:text-green-300">
                  My design approach focuses on understanding user needs and creating interfaces that are both beautiful and functional, leading to better conversion rates and user satisfaction.
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 p-6 rounded-2xl border-l-4 border-blue-500">
                <h3 className="font-space font-bold text-xl mb-3 text-blue-800 dark:text-blue-200 flex items-center">
                  <i className="fas fa-film mr-3 text-blue-600"></i>
                  Storytelling Excellence
                </h3>
                <p className="text-blue-700 dark:text-blue-300">
                  I craft narratives that connect with audiences on an emotional level, whether it's for film festivals or brand storytelling that helps businesses communicate their vision effectively.
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 p-6 rounded-2xl border-l-4 border-purple-500">
                <h3 className="font-space font-bold text-xl mb-3 text-purple-800 dark:text-purple-200 flex items-center">
                  <i className="fas fa-code mr-3 text-purple-600"></i>
                  Technical Expertise
                </h3>
                <p className="text-purple-700 dark:text-purple-300">
                  I specialize in modern web technologies and efficient development practices, ensuring projects are delivered on time with clean, maintainable code.
                </p>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-accent/5 p-6 rounded-2xl border border-accent/20">
                <h4 className="font-space font-bold text-lg mb-3 text-accent">Technical Excellence</h4>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill) => (
                    <span 
                      key={skill}
                      className="bg-accent/10 text-accent px-3 py-1 rounded-full text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="bg-[hsl(43,96%,56%)]/5 p-6 rounded-2xl border border-[hsl(43,96%,56%)]/20">
                <h4 className="font-space font-bold text-lg mb-3 text-[hsl(43,96%,56%)]">Track Record</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-neutral">Successful Projects</span>
                    <span className="font-bold text-[hsl(43,96%,56%)]">25+</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-neutral">Happy Clients</span>
                    <span className="font-bold text-[hsl(43,96%,56%)]">20+</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-neutral">Response Time</span>
                    <span className="font-bold text-[hsl(43,96%,56%)]">2 hours</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
