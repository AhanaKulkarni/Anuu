import { SOCIAL_LINKS } from "@/lib/constants";
import { Mail, Phone, MapPin } from "lucide-react";

export function ContactSection() {
  return (
    <section id="contact" className="py-20 bg-white dark:bg-black">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-accent font-medium text-lg">Let's Connect</span>
          <h2 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6">
            Ready to <span className="gradient-text">Collaborate?</span>
          </h2>
          <p className="text-neutral text-xl max-w-3xl mx-auto">
            Whether you need a website, a compelling user interface, or a powerful narrative for your next project — I'd love to help bring your vision to life.
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto">
          {/* Main Social Media Links Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {SOCIAL_LINKS.map((social, index) => (
              <a
                key={social.label}
                href={social.url}
                target={social.url.startsWith('http') ? '_blank' : '_self'}
                rel={social.url.startsWith('http') ? 'noopener noreferrer' : undefined}
                className="group flex items-center gap-6 p-8 bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent/20 to-accent/10 group-hover:from-accent group-hover:to-accent/80 flex items-center justify-center transition-all duration-300">
                  <i className={`${social.icon} text-2xl text-accent group-hover:text-white`}></i>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-xl text-foreground group-hover:text-accent transition-colors duration-300 mb-2">
                    {social.label}
                  </h3>
                  <p className="text-neutral text-sm">
                    {social.label === 'LinkedIn' ? 'Professional profile & updates' :
                     social.label === 'Instagram' ? '@ahanapk - Creative work & process' :
                     social.label === 'GitHub' ? 'Code repositories & projects' :
                     social.label === 'WhatsApp' ? '+91 8928352406 - Quick chat' :
                     social.label === 'Email' ? 'ahanapk2319@gmail.com' :
                     'Connect with me'}
                  </p>
                </div>
                <div className="text-accent group-hover:text-white transition-colors duration-300">
                  <i className="fas fa-arrow-right text-lg"></i>
                </div>
              </a>
            ))}
          </div>

          {/* Quick Contact Section */}
          <div className="text-center bg-gradient-to-r from-accent/10 via-accent/5 to-transparent p-12 rounded-3xl">
            <h3 className="text-2xl font-bold text-foreground mb-4">Ready to Start Your Project?</h3>
            <p className="text-neutral text-lg mb-8 max-w-2xl mx-auto">
              Whether you need UI/UX design, frontend development, or scriptwriting - let's bring your vision to life.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="tel:+918928352406"
                className="inline-flex items-center justify-center px-8 py-4 bg-accent hover:bg-accent/90 text-white rounded-full transition-all duration-300 transform hover:scale-105 font-semibold"
              >
                <i className="fas fa-phone mr-3"></i>
                Call Now
              </a>
              <a 
                href="mailto:ahanakulkarni@example.com"
                className="inline-flex items-center justify-center px-8 py-4 bg-foreground hover:bg-foreground/90 text-white rounded-full transition-all duration-300 transform hover:scale-105 font-semibold"
              >
                <i className="fas fa-envelope mr-3"></i>
                Send Email
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}