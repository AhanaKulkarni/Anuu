import { Button } from "@/components/ui/button";
import { SOCIAL_LINKS } from "@/lib/constants";
import { useEffect } from "react";
import { initializeAnimations } from "@/lib/animations";
import { initAllInteractiveEffects } from "@/lib/interactiveEffects";
import { initializeAll3DAnimations } from "@/lib/3dScrollAnimations";

export function HeroSection() {
  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  useEffect(() => {
    initializeAnimations();
    initAllInteractiveEffects();
    initializeAll3DAnimations();
  }, []);

  return (
    <section id="home" className="hero-section min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-white pt-16 dark:from-gray-900 dark:to-black parallax-container">
      {/* Floating particles background */}
      <div className="floating-particles">
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className="particle morphing-shape"
            style={{
              width: Math.random() * 100 + 50 + 'px',
              height: Math.random() * 100 + 50 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              animationDelay: Math.random() * 6 + 's'
            }}
          />
        ))}
      </div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 grid lg:grid-cols-2 gap-12 items-center">
        <div className="text-center lg:text-left">
          <div className="mb-6">
            <div className="flex flex-wrap gap-3 mb-6 hero-badge">
              <span className="inline-block px-4 py-2 bg-accent/10 text-accent rounded-full text-sm font-medium glow-on-hover">
                Available for High-Impact Projects
              </span>
              <span className="inline-block px-4 py-2 bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200 rounded-full text-sm font-medium">
                Premium Tier Specialist
              </span>
            </div>
            <h1 className="hero-title text-4xl md:text-6xl lg:text-7xl font-bold font-space leading-tight mb-4">
              <span className="split-text">Ahana</span>
              <span className="gradient-text-animated block">Kulkarni</span>
            </h1>
            <div className="mt-8 mb-6">
              <span className="hero-subtitle text-2xl md:text-3xl lg:text-4xl text-neutral font-normal typewriter block">Multi-Disciplinary Creative</span>
            </div>
          </div>
          
          <p className="hero-subtitle text-lg md:text-xl text-neutral mb-6 max-w-2xl font-medium">
            Frontend Developer · UI/UX Designer · Scriptwriter · Creative Director
          </p>
          
          <div className="hero-description bg-gradient-to-r from-accent/5 to-[hsl(43,96%,56%)]/5 p-6 rounded-2xl border-l-4 border-accent mb-8 max-w-2xl card-hover-effect">
            <p className="text-neutral leading-relaxed text-lg">
              I transform <strong>ambitious visions into digital realities</strong> that drive meaningful results. My approach combines thoughtful design, clean development, and compelling storytelling to create experiences that truly connect with users.
            </p>
          </div>
          
          <div className="hero-stats stagger-item grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 text-sm">
            <div className="stagger-child bg-green-50 dark:bg-green-900/20 p-3 rounded-xl text-center card-hover-effect">
              <div className="w-3 h-3 bg-green-500 rounded-full mx-auto mb-2 animate-pulse"></div>
              <span className="text-green-800 dark:text-green-200 font-medium">Quick Response</span>
            </div>
            <div className="stagger-child bg-accent/5 p-3 rounded-xl text-center card-hover-effect">
              <div className="w-3 h-3 bg-accent rounded-full mx-auto mb-2"></div>
              <span className="text-accent font-medium">Quality Work</span>
            </div>
            <div className="stagger-child bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl text-center card-hover-effect">
              <div className="w-3 h-3 bg-blue-500 rounded-full mx-auto mb-2"></div>
              <span className="text-blue-800 dark:text-blue-200 font-medium">Creative Excellence</span>
            </div>
            <div className="stagger-child bg-[hsl(43,96%,56%)]/10 p-3 rounded-xl text-center card-hover-effect">
              <div className="w-3 h-3 bg-[hsl(43,96%,56%)] rounded-full mx-auto mb-2"></div>
              <span className="text-[hsl(43,96%,56%)] font-medium">Happy Clients</span>
            </div>
          </div>
          
          <div className="hero-buttons flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
            <Button 
              onClick={() => handleNavClick("#contact")}
              className="animated-button magnetic-button liquid-button text-white px-8 py-4 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center justify-center shadow-lg hover:shadow-xl relative z-10"
            >
              <span className="font-semibold relative z-20">Let's Connect</span>
              <i className="fas fa-arrow-right ml-2 relative z-20"></i>
            </Button>
            <Button 
              onClick={() => handleNavClick("#portfolio")}
              className="animated-button magnetic-button physics-float bg-gradient-to-r from-[hsl(43,96%,56%)] to-[hsl(43,96%,46%)] hover:from-[hsl(43,96%,46%)] hover:to-[hsl(43,96%,36%)] text-white px-8 py-4 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center justify-center shadow-lg"
            >
              <span className="font-semibold">View My Work</span>
              <i className="fas fa-eye ml-2"></i>
            </Button>
          </div>
          
          {/* Social Links */}
          <div className="hero-social flex gap-6 justify-center lg:justify-start mt-8">
            {SOCIAL_LINKS.map((social, index) => (
              <a
                key={social.label}
                href={social.url}
                className="text-neutral hover:text-accent transition-colors duration-300 text-xl interactive"
                aria-label={social.label}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <i className={social.icon}></i>
              </a>
            ))}
          </div>
        </div>
        
        <div className="hero-image relative animate-slide-up parallax-element">
          <div className="relative tilt-card">
            <img 
              src="/ahana-photo.png" 
              alt="Ahana Kulkarni - Creative Professional" 
              className="rounded-3xl shadow-2xl w-full max-w-md mx-auto animate-float object-cover card-hover-effect"
            />
            
            {/* Floating Elements */}
            <div className="absolute -top-6 -right-6 bg-white rounded-2xl p-4 shadow-lg animate-float dark:bg-gray-800" style={{animationDelay: '0.5s'}}>
              <i className="fas fa-code text-accent text-2xl"></i>
            </div>
            
            <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl p-4 shadow-lg animate-float dark:bg-gray-800" style={{animationDelay: '1s'}}>
              <i className="fas fa-palette text-[hsl(43,96%,56%)] text-2xl"></i>
            </div>
            
            <div className="absolute top-1/2 -left-4 bg-white rounded-2xl p-3 shadow-lg animate-float dark:bg-gray-800" style={{animationDelay: '1.5s'}}>
              <i className="fas fa-film text-accent text-xl"></i>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
