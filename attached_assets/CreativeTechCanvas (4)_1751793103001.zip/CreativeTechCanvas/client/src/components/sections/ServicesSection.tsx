import { SERVICES, ADDITIONAL_SERVICES } from "@/lib/constants";

export function ServicesSection() {
  return (
    <section id="services" className="section-reveal py-20 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-accent font-medium text-lg">What I Do</span>
          <h2 className="text-4xl md:text-5xl font-bold font-space mt-2 mb-6 split-text">
            Services & <span className="gradient-text-animated">Expertise</span>
          </h2>
          <p className="text-neutral text-xl max-w-3xl mx-auto">
            From concept to creation, I deliver comprehensive solutions across design, development, and storytelling
          </p>
        </div>
        
        <div className="stagger-item grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, index) => (
            <div key={service.title} className="stagger-child service-card bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 group card-hover-effect glow-on-hover" style={{animationDelay: `${index * 0.2}s`}}>
              <div className={`bg-${service.color === 'accent' ? 'accent' : '[hsl(43,96%,56%)]'}/10 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-${service.color === 'accent' ? 'accent' : '[hsl(43,96%,56%)]'}/20 transition-colors`}>
                <i className={`${service.icon} text-${service.color === 'accent' ? 'accent' : '[hsl(43,96%,56%)]'} text-2xl`}></i>
              </div>
              <h3 className="font-space font-bold text-xl mb-4">{service.title}</h3>
              <p className="text-neutral mb-6">
                {service.description}
              </p>
              <div className="space-y-2 text-sm text-neutral">
                {service.features.map((feature) => (
                  <div key={feature} className="flex items-center">
                    <i className={`fas fa-check text-${service.color === 'accent' ? 'accent' : '[hsl(43,96%,56%)]'} mr-2`}></i>
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        {/* Additional Services */}
        <div className="mt-12 bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-lg">
          <h3 className="font-space font-bold text-2xl mb-6 text-center">Additional Services</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {ADDITIONAL_SERVICES.map((service) => (
              <div key={service.title} className="text-center">
                <i className={`${service.icon} text-accent text-3xl mb-4`}></i>
                <h4 className="font-semibold mb-2">{service.title}</h4>
                <p className="text-sm text-neutral">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
